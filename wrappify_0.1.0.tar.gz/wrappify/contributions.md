# Eric Baxter
- Wrote getArtistInfo, getSongInfo, getRelatedArtists, getTopSongs, and getAudioFeatures functions, along with all documentation and tests for those.
- Worked on CI.
- Did initial work on unittest structure.
- Built the final package structure.
- Wrote the code of conduct and description files.


# Aditya Saluja

# Luka Vukovic
