library(testthat)
library(wrappify)

test_check("wrappify")
